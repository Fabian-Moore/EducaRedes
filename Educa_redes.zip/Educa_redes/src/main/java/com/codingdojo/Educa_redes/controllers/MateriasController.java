package com.codingdojo.Educa_redes.controllers;

import org.springframework.web.bind.annotation.GetMapping;

public class MateriasController {

	
    @GetMapping("/matematicas")
    public String mostrarPaginaMatematicas() {
        return "matematicas.jsp"; // 
    }
}
