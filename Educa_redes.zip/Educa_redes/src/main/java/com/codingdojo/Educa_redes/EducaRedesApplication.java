package com.codingdojo.Educa_redes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducaRedesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducaRedesApplication.class, args);
	}

}
