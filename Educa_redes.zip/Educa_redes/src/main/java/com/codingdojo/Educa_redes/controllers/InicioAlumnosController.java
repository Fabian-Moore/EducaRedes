package com.codingdojo.Educa_redes.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.codingdojo.Educa_redes.models.User;
import com.codingdojo.Educa_redes.service.UserService;

import jakarta.servlet.http.HttpSession; // Importa la clase HttpSession para trabajar con sesiones.

@Controller // Anotación que indica que esta clase es un controlador de Spring MVC
public class InicioAlumnosController {

	private final UserService userService;
	
	   public InicioAlumnosController(UserService userService) {
	        this.userService = userService;
	    }
	@GetMapping("/InicioAlumnos")
	public String dashboard(HttpSession sesion, Model model) {
		Long userId = (Long) sesion.getAttribute("userID");
		if(userId == null) {
			return "redirect:/";
		}
		User user = userService.encontrarPorId(userId);
		model.addAttribute("user", user);
		return "InicioAlumnos.jsp";
	}
    
   

    
    @GetMapping("/logout") // Maneja solicitudes GET a la ruta /logout para cerrar sesión
    public String logout(HttpSession session) {
    	
        // Realiza la invalidación de la sesión al cerrar sesión
        session.invalidate();

        // Redirige a la página "inicio.jsp" después de cerrar sesión
        return "redirect:/";
    }
}
