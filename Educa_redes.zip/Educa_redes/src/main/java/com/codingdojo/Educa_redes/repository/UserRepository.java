package com.codingdojo.Educa_redes.repository;

import org.springframework.data.repository.CrudRepository;

import com.codingdojo.Educa_redes.models.User;

public interface UserRepository extends CrudRepository<User, Long> {

    User findByEmail(String email);
}
