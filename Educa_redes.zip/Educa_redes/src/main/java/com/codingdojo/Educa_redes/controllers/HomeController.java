package com.codingdojo.Educa_redes.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import com.codingdojo.Educa_redes.models.LoginUser;
import com.codingdojo.Educa_redes.models.User;
import com.codingdojo.Educa_redes.service.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class HomeController {

    private final UserService userService;

    public HomeController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/") // Maneja solicitudes GET a la ruta /InicioAlumnos
    public String Inicio() {
        return "inicio.jsp"; // Devuelve la vista "InicioAlumnos.jsp"
    }

    // Maneja la solicitud para la página de inicio (ruta "/")
    @GetMapping("/login")
    public String index(Model model, HttpSession session) {
        // Agrega objetos de usuario para el formulario de registro e inicio de sesión a la vista
        model.addAttribute("login", new LoginUser());
        Long userId = (Long) session.getAttribute("userID");
		if(userId == null) {
			return "login.jsp";
		}
        return "redirect:/InicioAlumnos"; // Devuelve la vista "login.jsp"
    }
    
    @GetMapping("/register")
    public String register(Model model) {
        // Agrega objetos de usuario para el formulario de registro e inicio de sesión a la vista
        model.addAttribute("registro", new User());
        return "register.jsp"; // Devuelve la vista "login.jsp"
    }

    // Maneja la solicitud de registro (ruta "/register")
    @PostMapping("/register")
    public String registro(@Valid @ModelAttribute("registro") User nuevoUsuario,
            BindingResult resultado, Model model, HttpSession sesion) {

        if (resultado.hasErrors()) {
            // Si hay errores de validación, muestra la vista de inicio de sesión nuevamente
            model.addAttribute("login", new LoginUser());
            return "login.jsp";
        }

        // Intenta registrar al usuario llamando al servicio
        User usuarioRegistrar = userService.registrarUsuario(nuevoUsuario, resultado);

        if (usuarioRegistrar != null) {
            // Si el registro fue exitoso, muestra la vista de inicio de sesión con un mensaje de éxito
            model.addAttribute("login", new LoginUser());
            model.addAttribute("registro", new User());
            model.addAttribute("registroExitoso", true);
            return "InicioAlumnos.jsp";
        } else {
            // Si hubo un problema en el registro, muestra la vista de inicio de sesión nuevamente
            model.addAttribute("login", new LoginUser());
            return "login.jsp";
        }
    }

    // Maneja la solicitud de inicio de sesión (ruta "/login")
    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("login") LoginUser loginuser,
            BindingResult resultado, Model model, HttpSession sesion) {

        if (resultado.hasErrors()) {
            // Si hay errores de validación, muestra la vista de inicio de sesión nuevamente
            model.addAttribute("registro", new User());
            return "login.jsp";
        }

        // Intenta autenticar al usuario llamando al servicio
        if (userService.autenticacionUser(loginuser.getEmail(), loginuser.getPassword(), resultado)) {
            User usuarioLog = userService.encontrarPorEmail(loginuser.getEmail());
            sesion.setAttribute("userID", usuarioLog.getId());
            
            // Redirige al usuario a InicioAlumnos.jsp después de iniciar sesión exitosamente
            return "redirect:/InicioAlumnos";
        } else {
            // Si la autenticación falla, muestra la vista de inicio de sesión nuevamente
            model.addAttribute("registro", new User());
            return "login.jsp";
        }
    }
    
    //Materias
    
    @GetMapping("/matematicas") // Maneja solicitudes GET a la ruta /InicioAlumnos
    public String matematicas(HttpSession session,Model model) {
    	Long userId = (Long) session.getAttribute("userID");
		if(userId == null) {
			return "redirect:/";
		}
		User user = userService.encontrarPorId(userId);
		model.addAttribute("user", user);

        return "matematicas.jsp"; // Devuelve la vista "InicioAlumnos.jsp"
    }
    
    @GetMapping("/ciencias") // Maneja solicitudes GET a la ruta /InicioAlumnos
    public String ciencias(HttpSession session, Model model) {
    	Long userId = (Long) session.getAttribute("userID");
		if(userId == null) {
			return "redirect:/";
		}
		User user = userService.encontrarPorId(userId);
		model.addAttribute("user", user);
		
        return "ciencias.jsp"; // Devuelve la vista "InicioAlumnos.jsp"
    }
    
    @GetMapping("/lenguaje") // Maneja solicitudes GET a la ruta /InicioAlumnos
    public String lenguaje(HttpSession session, Model model) {
    	Long userId = (Long) session.getAttribute("userID");
		if(userId == null) {
			return "redirect:/";
		}
		User user = userService.encontrarPorId(userId);
		model.addAttribute("user", user);
        return "lenguaje.jsp"; // Devuelve la vista "InicioAlumnos.jsp"
    }
    
    @GetMapping("/historia") // Maneja solicitudes GET a la ruta /InicioAlumnos
    public String historia(HttpSession session, Model model) {
    	Long userId = (Long) session.getAttribute("userID");
		if(userId == null) {
			return "redirect:/";
		}
		User user = userService.encontrarPorId(userId);
		model.addAttribute("user", user);
        return "historia.jsp"; // Devuelve la vista "InicioAlumnos.jsp"
    }
    
    @GetMapping("/ingles") // Maneja solicitudes GET a la ruta /InicioAlumnos
    public String ingles( HttpSession session, Model model) {
    	Long userId = (Long) session.getAttribute("userID");
		if(userId == null) {
			return "redirect:/";
		}
		User user = userService.encontrarPorId(userId);
		model.addAttribute("user", user);
        return "ingles.jsp"; // Devuelve la vista "InicioAlumnos.jsp"
    }
    
    
    @GetMapping("/contacto") // Maneja solicitudes GET a la ruta /InicioAlumnos
    public String contacto(HttpSession session) {
    
        return "contacto.jsp"; // Devuelve la vista "InicioAlumnos.jsp"
    }
    
    @GetMapping("/perfil") // Maneja solicitudes GET a la ruta /InicioAlumnos
    public String perfil(HttpSession session) {
    	Long userId = (Long) session.getAttribute("userID");
		if(userId == null) {
			return "redirect:/";
		}
        return "perfil.jsp"; // Devuelve la vista "InicioAlumnos.jsp"
    }
    
    
    //@PostMapping("/olvidarcontraseñacorreo")
   // public String enviarcorreo() {
    	
    	//return "enviarcorreo.jsp";
    //}
    
}

//..


